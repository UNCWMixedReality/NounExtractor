# Noun Extractor
### A cloud service based natural language processing pipeline
Created by the UNCW Mixed Reality Lab

## Usage
TBD

